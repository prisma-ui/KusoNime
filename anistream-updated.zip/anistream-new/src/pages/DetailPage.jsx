import { useState } from "react";
import { useApi } from "../hooks/useApi";
import VideoPlayer from "../components/VideoPlayer";
import EpisodeList from "../components/EpisodeList";
import AnimeCard from "../components/AnimeCard";
import { getTitle, getImg, getBanner, cleanHtml } from "../utils/helpers";

export default function DetailPage({ animeId, onBack, onRelated }) {
  const { data, loading } = useApi(`/info/${animeId}`, [animeId]);
  const [episode, setEpisode] = useState(null);
  const [descExpanded, setDescExpanded] = useState(false);

  if (loading)
    return (
      <div className="loading-full">
        <div className="spinner" />
        <p>Loading anime details...</p>
      </div>
    );
  if (!data)
    return (
      <div className="error-msg">
        <h3>Anime not found</h3>
      </div>
    );

  const anime = data?.data || data;
  const title = getTitle(anime);
  const desc = cleanHtml(anime?.description);
  const banner = getBanner(anime);
  const img = getImg(anime);
  const score = anime?.averageScore || anime?.meanScore;
  const genres = anime?.genres || [];
  const recs =
    anime?.recommendations?.nodes || anime?.recommendations || [];

  return (
    <div className="detail-page fade-in">
      <div className="detail-hero">
        <div
          className="detail-hero-bg"
          style={{ backgroundImage: `url(${banner || img})` }}
        />
        <div className="detail-hero-grad" />
      </div>
      <div className="detail-body">
        <button className="back-btn" onClick={onBack}>
          ← Back
        </button>
        <div className="detail-top">
          <div className="detail-poster">
            {img && <img src={img} alt={title} />}
          </div>
          <div className="detail-meta">
            <h1 className="detail-title">{title}</h1>
            {anime?.title?.romaji && anime.title.romaji !== title && (
              <p className="detail-eng">{anime.title.romaji}</p>
            )}
            <div className="detail-stats">
              {score && (
                <div className="detail-stat">
                  <div className="detail-stat-val">
                    ★ {(score / 10).toFixed(1)}
                  </div>
                  <div className="detail-stat-lab">Score</div>
                </div>
              )}
              {anime?.episodes && (
                <div className="detail-stat">
                  <div className="detail-stat-val">{anime.episodes}</div>
                  <div className="detail-stat-lab">Episodes</div>
                </div>
              )}
              {anime?.duration && (
                <div className="detail-stat">
                  <div className="detail-stat-val">{anime.duration}m</div>
                  <div className="detail-stat-lab">Duration</div>
                </div>
              )}
              {anime?.seasonYear && (
                <div className="detail-stat">
                  <div className="detail-stat-val">{anime.seasonYear}</div>
                  <div className="detail-stat-lab">Year</div>
                </div>
              )}
              {anime?.popularity && (
                <div className="detail-stat">
                  <div className="detail-stat-val">
                    {anime.popularity?.toLocaleString()}
                  </div>
                  <div className="detail-stat-lab">Popularity</div>
                </div>
              )}
            </div>
            <div className="detail-genres">
              {anime?.format && (
                <span className={`format-badge format-${anime.format}`}>
                  {anime.format}
                </span>
              )}
              {anime?.status && (
                <span
                  className="genre-pill"
                  style={{
                    color:
                      anime.status === "RELEASING" ? "#34d399" : undefined,
                  }}
                >
                  {anime.status === "RELEASING"
                    ? "Currently Airing"
                    : anime.status}
                </span>
              )}
              {genres.slice(0, 6).map((g) => (
                <span key={g} className="genre-pill">
                  {g}
                </span>
              ))}
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button
                className="btn btn-primary"
                onClick={() =>
                  document
                    .getElementById("ep-section")
                    ?.scrollIntoView({ behavior: "smooth" })
                }
              >
                ▶ Watch
              </button>
            </div>
          </div>
        </div>

        {desc && (
          <div style={{ marginTop: "1.5rem" }}>
            <p className={`detail-desc ${descExpanded ? "" : "collapsed"}`}>
              {desc}
            </p>
            <button
              className="toggle-desc"
              onClick={() => setDescExpanded((e) => !e)}
            >
              {descExpanded ? "Show less ↑" : "Show more ↓"}
            </button>
          </div>
        )}

        <div id="ep-section">
          <VideoPlayer animeId={animeId} episode={episode} />
          <EpisodeList
            animeId={animeId}
            onEpSelect={setEpisode}
            currentEp={episode}
          />
        </div>

        {recs.length > 0 && (
          <div style={{ marginTop: "2.5rem" }}>
            <h3 className="section-title" style={{ marginBottom: "1rem" }}>
              Recommendations
            </h3>
            <div className="recommendations">
              {recs.slice(0, 12).map((r, i) => {
                const rec =
                  r?.node?.mediaRecommendation || r?.node || r;
                if (!rec?.id) return null;
                return (
                  <AnimeCard
                    key={i}
                    anime={rec}
                    onClick={() => onRelated(rec?.id)}
                  />
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
