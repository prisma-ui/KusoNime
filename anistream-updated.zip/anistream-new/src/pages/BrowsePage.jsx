import { useState } from "react";
import { useApi } from "../hooks/useApi";
import AnimeCard from "../components/AnimeCard";
import SkeletonCards from "../components/SkeletonCards";

export default function BrowsePage({ tab, onAnimeClick }) {
  const tabs = [
    { id: "trending", label: "Trending", url: "/trending?per_page=24" },
    { id: "popular", label: "Popular", url: "/popular?per_page=24" },
    { id: "upcoming", label: "Upcoming", url: "/upcoming?per_page=24" },
    { id: "recent", label: "Recent", url: "/recent?per_page=24" },
  ];
  const [active, setActive] = useState(tab || "trending");
  const cur = tabs.find((t) => t.id === active);
  const { data, loading } = useApi(cur?.url, [active]);
  const list = data?.results || data?.data || [];

  return (
    <div className="fade-in">
      <div className="page-tabs">
        {tabs.map((t) => (
          <button
            key={t.id}
            className={`page-tab ${active === t.id ? "active" : ""}`}
            onClick={() => setActive(t.id)}
          >
            {t.label}
          </button>
        ))}
      </div>
      <div className="section">
        {loading ? (
          <SkeletonCards count={20} />
        ) : (
          <div className="cards-row wide">
            {list.map((anime, i) => (
              <AnimeCard key={i} anime={anime} onClick={onAnimeClick} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
