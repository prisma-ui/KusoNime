import { useState, useEffect } from "react";
import { useApi } from "../hooks/useApi";

export default function EpisodeList({ animeId, onEpSelect, currentEp }) {
  const { data, loading } = useApi(`/episodes/${animeId}`, [animeId]);
  const [provider, setProvider] = useState(null);

  const providers = data ? Object.keys(data) : [];

  useEffect(() => {
    if (providers.length && !provider) setProvider(providers[0]);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [providers.join(",")]);

  if (loading)
    return (
      <div className="loading-full">
        <div className="spinner" />
      </div>
    );
  if (!data || providers.length === 0)
    return (
      <div className="error-msg">
        <p>No episodes found.</p>
      </div>
    );

  const episodes = provider ? data[provider] || [] : [];

  return (
    <div className="ep-section">
      <div className="ep-tabs">
        {providers.map((p) => (
          <button
            key={p}
            className={`ep-tab ${provider === p ? "active" : ""}`}
            onClick={() => setProvider(p)}
          >
            {p.charAt(0).toUpperCase() + p.slice(1)}
          </button>
        ))}
      </div>
      {episodes.length === 0 ? (
        <p style={{ color: "var(--muted)", fontSize: "0.85rem" }}>
          No episodes for this provider.
        </p>
      ) : (
        <div className="ep-grid">
          {episodes.map((ep, i) => {
            const epNum = ep?.number || ep?.episodeId || i + 1;
            const epId = ep?.id || ep?.episodeId || ep?.slug;
            return (
              <button
                key={i}
                className={`ep-btn ${currentEp?.id === epId ? "current" : ""}`}
                title={ep?.title || `Episode ${epNum}`}
                onClick={() =>
                  onEpSelect({
                    ...ep,
                    _provider: provider,
                    id: epId,
                    num: epNum,
                  })
                }
              >
                {epNum}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
