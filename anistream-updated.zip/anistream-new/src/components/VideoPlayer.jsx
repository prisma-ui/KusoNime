import { useState, useEffect } from "react";
import { API_BASE } from "../utils/constants";

export default function VideoPlayer({ animeId, episode }) {
  const [sources, setSources] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [srcIdx, setSrcIdx] = useState(0);

  useEffect(() => {
    if (!episode) return;
    setLoading(true);
    setSources(null);
    setError(null);
    setSrcIdx(0);
    const epId = episode?.id || episode?.episodeId;
    const provider = episode?._provider || "zoro";
    const cat = episode?.category || "sub";
    const url = `${API_BASE}/sources?episodeId=${encodeURIComponent(epId)}&provider=${provider}&anilistId=${animeId}&category=${cat}`;
    fetch(url)
      .then((r) => r.json())
      .then((d) => {
        setSources(d);
        setLoading(false);
      })
      .catch(() => {
        setError("Could not load video sources.");
        setLoading(false);
      });
  }, [episode?.id, animeId]);

  if (!episode)
    return (
      <div className="player-section">
        <div
          className="player-container"
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexDirection: "column",
            gap: 12,
            color: "var(--muted)",
          }}
        >
          <span style={{ fontSize: "3rem" }}>▶</span>
          <p style={{ fontSize: "0.9rem" }}>
            Select an episode to start watching
          </p>
        </div>
      </div>
    );

  const srcs = sources?.sources || sources?.data?.sources || [];
  const embedUrl = sources?.embed || sources?.data?.embed || null;
  const src = srcs[srcIdx];
  const streamUrl = embedUrl || src?.url || src?.file;

  return (
    <div className="player-section">
      <div className="player-header">
        <div
          className="play-btn"
          style={{ width: 28, height: 28, fontSize: "0.7rem", flexShrink: 0 }}
        >
          ▶
        </div>
        <span className="player-ep-title">
          Episode {episode?.num || episode?.number}
        </span>
        {episode?.title && (
          <span style={{ color: "var(--muted)", fontSize: "0.8rem" }}>
            — {episode.title}
          </span>
        )}
        {srcs.length > 1 && (
          <div className="player-provider-tabs">
            {srcs.map((s, i) => (
              <button
                key={i}
                className={`ep-tab ${i === srcIdx ? "active" : ""}`}
                onClick={() => setSrcIdx(i)}
                style={{ fontSize: "0.72rem", padding: "3px 10px" }}
              >
                {s?.quality || s?.label || `#${i + 1}`}
              </button>
            ))}
          </div>
        )}
      </div>
      <div className="player-container">
        {loading && (
          <div className="source-loading">
            <div className="spinner" />
            <p style={{ color: "var(--muted)", fontSize: "0.85rem" }}>
              Loading sources...
            </p>
          </div>
        )}
        {error && (
          <div className="source-loading">
            <p style={{ color: "var(--muted)", fontSize: "0.85rem" }}>
              ⚠️ {error}
            </p>
          </div>
        )}
        {!loading && !error && streamUrl && (
          <iframe
            src={streamUrl}
            allowFullScreen
            allow="autoplay; fullscreen; picture-in-picture"
            title={`Episode ${episode?.num}`}
          />
        )}
        {!loading && !error && !streamUrl && srcs.length === 0 && (
          <div className="source-loading">
            <p style={{ color: "var(--muted)", fontSize: "0.85rem" }}>
              No playable source found for this episode.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
